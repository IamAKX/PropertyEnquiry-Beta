<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
   	$type=$_REQUEST['type'];
	if($type=="new")
	{
		$conn = new mysqli("mysql.hostinger.in", "u378051239_anam", "anam1234", "u378051239_pe");
		// Check connection
		if ($conn->connect_error) 
		{
  			  die("Connection failed: " . $conn->connect_error);
		} 
	
	$sql = "SELECT * FROM property WHERE type='project'";

	$result = $conn->query($sql);

	if ($result->num_rows > 0) {
     // output data of each row
     while($row = $result->fetch_assoc()) {
    	  echo $row['id']."#".$row['name']."#".$row['builder']."#".$row['address']."#".$row['bhk']."#".$row['price']."#".$row['phone']."#".$row['possession']."#".$row['details']."#".$row['url']."#";
     }
	 } else 
	 {
     echo "fail";
}
$conn->close();
}
}
?>
<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
   	$type=$_REQUEST['type'];
	if($type=="new")
	{
		$id = $_REQUEST['id'];
		$conn = new mysqli("mysql.hostinger.in", "u378051239_anam", "anam1234", "u378051239_pe");
		// Check connection
		if ($conn->connect_error) 
		{
  			  die("Connection failed: " . $conn->connect_error);
		} 
	
	$sql = "SELECT * FROM images WHERE propertyid=".$id;

	$result = $conn->query($sql);

	if ($result->num_rows > 0) {
     // output data of each row
     while($row = $result->fetch_assoc()) {
    	  echo $row['url'];
     }
	 } else 
	 {
     echo "fail";
}
$conn->close();
}
}
?>
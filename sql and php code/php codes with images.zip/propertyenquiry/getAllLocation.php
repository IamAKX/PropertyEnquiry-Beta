<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
   	$type=$_REQUEST['type'];
	if($type=="new")
	{
		$conn = new mysqli("mysql.hostinger.in", "u378051239_anam", "anam1234", "u378051239_pe");
		// Check connection
		if ($conn->connect_error) 
		{
  			  die("Connection failed: " . $conn->connect_error);
		} 
	
	$sql = "SELECT DISTINCT address FROM property ORDER BY address";

	$result = $conn->query($sql);

	if ($result->num_rows > 0) {
       echo $result->num_rows ."#";
     // output data of each row
     while($row = $result->fetch_assoc()) {
    	  echo $row['address']."#";
     }
	 } else 
	 {
     echo "No Location found.#";
}
$conn->close();
}
}
?>
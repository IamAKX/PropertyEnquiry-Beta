<?php

 if ($_SERVER["REQUEST_METHOD"] == "POST") {
   
	$type=$_REQUEST['type'];
	if($type=="new")
	{
		$name = $_REQUEST['name'];
		$email=$_REQUEST['email'];
		$pass=$_REQUEST['password'];
		$conn = new mysqli("mysql.hostinger.in", "u378051239_anam", "anam1234", "u378051239_pe");
		// Check connection
		if ($conn->connect_error) {
  			  die("Connection failed: " . $conn->connect_error);
		} 
		
		$sql1 = "SELECT * FROM user WHERE email='".$email."'";
		$result = $conn->query($sql1);

		
	if ($result->num_rows > 0) 
	{
		echo "duplicate";
	} 
	else 
	{
		$sql = "INSERT INTO user(name,email, password, profilepic) 
				VALUES ('".$name."' , '".$email."','".$pass."','')";

		if ($conn->query($sql) === TRUE) 
		{
			mail($email,"PROPERTY ENQUIRY Registration Acknowledgement!!","Dear ".$name.", You are successfully registered to our server and now you will receive updates and information frequently. \n\n-------Your  Personal Detail------\n\nYour Bank Id : \nLogging ID :   ".$email."\nYour password : ".$pass."\n\nTHANK YOU!!!");	
			echo "success";
		} 
		else 
		{
			echo "Error: " . $sql . "<br>" . $conn->error;
		}
	}
		
	$conn->close();
	}
}
?>
<?php
  
if ($_SERVER["REQUEST_METHOD"] == "POST") {
   	$type=$_REQUEST['type'];
	if($type=="new")
	{
		$conn = new mysqli("mysql.hostinger.in", "u378051239_anam", "anam1234", "u378051239_pe");
		// Check connection
		if ($conn->connect_error) 
		{
echo "yes"; 
  			  die("Connection failed: " . $conn->connect_error);
		} 
	
	$sql = "SELECT DISTINCT builder FROM property ORDER BY builder";

	$result = $conn->query($sql);

	if ($result->num_rows > 0) {
echo $result->num_rows ."#";
     // output data of each row
     while($row = $result->fetch_assoc()) {
 	 
 echo $row['builder']."#";
     }
	 } else 
	 {
     echo "No Builder found.#";
}
$conn->close();
}
}
?>	
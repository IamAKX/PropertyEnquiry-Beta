<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
   	$type=$_REQUEST['type'];
	if($type=="new")
	{
		$email=$_REQUEST['email'];
		$conn = new mysqli("mysql.hostinger.in", "u378051239_anam", "anam1234", "u378051239_pe");
		// Check connection
		if ($conn->connect_error) {
  			  die("Connection failed: " . $conn->connect_error);
		} 
	
$sql = "SELECT * FROM user WHERE email='".$email."'";

$result = $conn->query($sql);

if ($result->num_rows > 0) {
     // output data of each row
     while($row = $result->fetch_assoc()) {
          mail($email,"Password recovery","Dear ".$row['name'].", Your password have been recovered from our database. Your credentials are as follow:\n Login ID : ".$row['email']."\n Password is : ".$row['password']);
		  echo "success";
     }
} else {
     echo "fail";
}
$conn->close();
}
}
?>
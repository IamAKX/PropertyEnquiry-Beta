<?php
		$name=$_GET['name'];
		$builder=$_GET['builder'];
        $location=$_GET['location'];
		$typeee=$_GET['typeee'];

		$conn = new mysqli("mysql.hostinger.in", "u378051239_anam", "anam1234", "u378051239_pe");
		// Check connection
		if ($conn->connect_error) {
  			  die("Connection failed: " . $conn->connect_error);
		} 
	
		$sql = "SELECT * FROM property WHERE `name` = '".$name."' OR `builder` = '".$builder."' OR `address` = '".$location."' OR `type` = '".$typeee."'";
?>
	<head>
		<link rel="stylesheet" type="text/css" href="myStyle.css">
	</head>
	<body>
	
	<?php
		$result = $conn->query($sql);

		if ($result->num_rows > 0) {
     // output data of each row
		while($row = $result->fetch_assoc()) {
	?>
		<div class="material">
			<img src=<?php echo $row['url'];?> style="width:330px;height:180px"/>
			<hr/>
			<div style="font-weight:bold;"><?php echo $row['name'];?></div>
			<div><?php echo $row['builder'];?></div>
			<div>
				<span><?php echo $row['address'];?></span>
				<span style="float:right;"><?php echo $row['price'];?></span>
			</div>
		</div>
		<br/><br/>
	<?php	}
	} else {
     echo "noresult";
}
$conn->close();
}

}


?>				
	</body>
